<?php

/* overall/header.twig */
class __TwigTemplate_348c1dda644528390ae1237873e17a5dac4ac4620e99a317dbc4fc65f8120561 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<style>

.bg-image {
  /* The image used */
  background-image: url(\"assets/app/img/libro.jpg\");
  
  /* Full height */
  height: 512px;
  
  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
</style>
<header class=\"w3-display-container w3-center\">
    <div class=\"bg-image\"></div>
    <div class=\"mySlides w3-animate-opacity\">

        <!-- vista para small, ocultando medium -->
        <div class=\"w3-display-bottommiddle w3-padding w3-hide-medium\" style=\"width:75%\">
            <div class=\"w3-indigo w3-opacity w3-hover-opacity-off w3-padding-large w3-round-large\">
                <p class=\"\">Descarga el E-Book aquí</p>
                <hr class=\"w3-opacity\">
                <!--<p>Super simple installment: free of charge</p>-->
                <p>
                    <button class=\"w3-button w3-block w3-green w3-hover-white w3-round w3-hover-text-green\" onclick=\"document.getElementById('download').style.display='block'\">
                        Descargar <i class=\"fa fa-file\"></i>
                    </button>
                </p>
            </div>
        </div>

        <!-- vista para medium, ocultando small -->
        <div class=\"w3-display-left w3-padding w3-hide-small\" style=\"width:45%\">
            <div class=\"w3-indigo w3-opacity w3-hover-opacity-off w3-padding-large w3-round-large\">
                <p class=\"\">Descarga el E-Book aquí</p>
                <hr class=\"w3-opacity\">
                <!--<p>Super simple installment: free of charge</p>-->
                <p>
                    <button class=\"w3-button w3-block w3-green w3-hover-white w3-round w3-hover-text-green\" onclick=\"document.getElementById('download').style.display='block'\">
                        Descargar <i class=\"fa fa-file\"></i>
                    </button>
                </p>
            </div>
        </div>
    </div>
</header>";
    }

    public function getTemplateName()
    {
        return "overall/header.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<style>

.bg-image {
  /* The image used */
  background-image: url(\"assets/app/img/libro.jpg\");
  
  /* Full height */
  height: 512px;
  
  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
</style>
<header class=\"w3-display-container w3-center\">
    <div class=\"bg-image\"></div>
    <div class=\"mySlides w3-animate-opacity\">

        <!-- vista para small, ocultando medium -->
        <div class=\"w3-display-bottommiddle w3-padding w3-hide-medium\" style=\"width:75%\">
            <div class=\"w3-indigo w3-opacity w3-hover-opacity-off w3-padding-large w3-round-large\">
                <p class=\"\">Descarga el E-Book aquí</p>
                <hr class=\"w3-opacity\">
                <!--<p>Super simple installment: free of charge</p>-->
                <p>
                    <button class=\"w3-button w3-block w3-green w3-hover-white w3-round w3-hover-text-green\" onclick=\"document.getElementById('download').style.display='block'\">
                        Descargar <i class=\"fa fa-file\"></i>
                    </button>
                </p>
            </div>
        </div>

        <!-- vista para medium, ocultando small -->
        <div class=\"w3-display-left w3-padding w3-hide-small\" style=\"width:45%\">
            <div class=\"w3-indigo w3-opacity w3-hover-opacity-off w3-padding-large w3-round-large\">
                <p class=\"\">Descarga el E-Book aquí</p>
                <hr class=\"w3-opacity\">
                <!--<p>Super simple installment: free of charge</p>-->
                <p>
                    <button class=\"w3-button w3-block w3-green w3-hover-white w3-round w3-hover-text-green\" onclick=\"document.getElementById('download').style.display='block'\">
                        Descargar <i class=\"fa fa-file\"></i>
                    </button>
                </p>
            </div>
        </div>
    </div>
</header>", "overall/header.twig", "C:\\xampp\\htdocs\\m.gomuf\\app\\templates\\overall\\header.twig");
    }
}
