<?php

/* overall/layout.twig */
class __TwigTemplate_2107fddbdffedfd611d9ff6f5d5fe7e6436ac6cc1e5884c0bf182462e4cdcd2a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'appHeader' => array($this, 'block_appHeader'),
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>";
        // line 4
        echo $this->env->getExtension('Ocrend\Kernel\Helpers\Functions')->base_assets();
        echo "
    <title>";
        // line 5
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "build", array()), "name", array()), "html", null, true);
        echo "</title>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <link rel=\"stylesheet\" href=\"assets/vendor/ladda/ladda.min.css\">
    <link rel=\"stylesheet\" href=\"https://www.w3schools.com/w3css/4/w3.css\">
    <link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css?family=Poppins\">
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">
    <link rel=\"stylesheet\" href=\"https://www.w3schools.com/lib/w3-theme-black.css\">
    <link rel=\"stylesheet\" href=\"assets/vendor/toastr/build/toastr.min.css\">
    <link rel=\"stylesheet\" href=\"assets/app/css/app.css\">";
        // line 15
        $this->displayBlock('appHeader', $context, $blocks);
        // line 16
        echo "    <style>
        body,h1,h2,h3,h4,h5 {font-family: \"Poppins\", sans-serif}
        body {font-size: 16px;}
        img {margin-bottom: -8px;}
        .mySlides {display: none;}

        #sidetop a{
          margin:2%;
        }
    </style>
</head>
<body class=\"w3-content w3-blue\" style=\"max-width: 1400px\">

<!-- Navbar (sit on top) -->
<div class=\"w3-top topnav\" style=\"width: 100%\">
    <div class=\"w3-bar w3-white w3-wide w3-padding w3-card\">
        <a href=\"home\" class=\"w3-bar-item w3-button\"><b>GOMUF</b></a>
        <button class=\"w3-button w3-white w3-large w3-right w3-hide-large\" onclick=\"w3_open()\">&#9776;</button>
        <!-- Float links to the right. Hide them on small screens -->
        <!-- Sidebar -->
        <div class=\"w3-sidebar w3-bar-block w3-animate-right\" style=\"display:none;z-index:5; right: 0px;\" id=\"sidetop\">
          <p class=\"w3-large w3-center\"><b>Proyecto Global</b></p>
          <p class=\"w3-large w3-center\"><b><i>Metamorfosis Universitaria Fraternity</i></b></p>

          <!--<button class=\"w3-bar-item w3-button w3-large\" onclick=\"w3_close()\">Close &times;</button>-->
          <a href=\"#nosotros\" class=\"w3-bar-item w3-button w3-blue\" data-item=\"nosotros\">Nosotros</a>
          <a href=\"#valores\" class=\"w3-bar-item w3-button w3-blue\" data-item=\"valores\">Valores</a>
          <a href=\"#staff\" class=\"w3-bar-item w3-button w3-blue\" data-item=\"staff\">Staff</a>
          <a href=\"#campus_accion\" class=\"w3-bar-item w3-button w3-blue\" data-item=\"campus_accion\">Campus de Acción</a>
          <a href=\"#alianzas\" class=\"w3-bar-item w3-button w3-blue\" data-item=\"staff\">Alianzas</a>
          <a href=\"#contact\" class=\"w3-bar-item w3-button w3-blue\" data-item=\"contact\">Contacto</a>
          <br><br>
          <!-- aside bottom -->
          <div class=\"w3-row w3-display-middlebottom\">
            <button class=\"w3-button w3-inline\">
              <a href=\"mailto:gomuf.com@gmail.com\" target=\"_blanck\">
                <i class=\"fa fa-envelope-o w3-text-blue\"></i>
              </a>
            </button>
            <button class=\"w3-button\">
                  <a href=\"https://www.facebook.com/mufvalencia.ortegaalbornoz/\" target=\"_blanck\">
                <i class=\"fa fa-facebook w3-text-blue\"></i>
              </a>
            </button>
            <button class=\"w3-button\">
                  <a href=\"https://www.instagram.com/mufvalencia/\" target=\"_blanck\">
                <i class=\"fa fa-instagram w3-text-blue\"></i>
              </a>
            </button>
          </div>
          <br>
        </div>

        <div class=\"w3-right w3-hide-small w3-hide-medium w3-medium\">
            <a href=\"#nosotros\" class=\"w3-bar-item w3-button\" data-item=\"nosotros\">Nosotros</a>
            <a href=\"#valores\" class=\"w3-bar-item w3-button\" data-item=\"valores\">Valores</a>
            <a href=\"#staff\" class=\"w3-bar-item w3-button\" data-item=\"staff\">Staff</a>
            <a href=\"#campus_accion\" class=\"w3-bar-item w3-button\" data-item=\"campus_accion\">Campus de Acción</a>
            <a href=\"#alianzas\" class=\"w3-bar-item w3-button\" data-item=\"staff\">Alianzas</a>
            <a href=\"#contact\" class=\"w3-bar-item w3-button\" data-item=\"contact\">Contacto</a>
        </div>

        <!-- overlay -->
        <div class=\"w3-overlay w3-animate-opacity\" onclick=\"w3_close()\" style=\"cursor:pointer\" id=\"overlay_navtop\"></div>
    </div>
</div>




<header class=\"w3-container w3-center w3-padding-32 w3-white\" style=\"margin-top: 10%\">
  <img src=\"assets/app/img/logo.png\" class=\"w3-image\" width=\"200\" height=\"200\">
    <h1 class=\"w3-xlarge\"><b>Proyecto Global</b></h1>
    <h3 class=\"w3-large\"><b><i>Metamorfosis Universitaria Fraternity</i></b></h3>
</header>";
        // line 92
        $this->loadTemplate("overall/header", "overall/layout.twig", 92)->display($context);
        // line 95
        $this->displayBlock('appBody', $context, $blocks);
        // line 96
        echo "
<!-- Footer -->
<footer class=\"w3-container w3-padding-32 w3-light-grey w3-center w3-xlarge\">
  <p class=\"w3-medium\">Powered by <a href=\"https://www.w3schools.com/w3css/default.asp\" target=\"_blank\" class=\"w3-hover-text-green\">GoMuf Developers</a></p>
</footer>

<script>
// Slideshow
var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName(\"mySlides\");
  if (n > x.length) {slideIndex = 1}
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
    x[i].style.display = \"none\";  
  }
  x[slideIndex-1].style.display = \"block\";  
}
</script>

<script>
function w3_open() {
document.getElementById(\"sidetop\").style.display = \"block\";
document.getElementById(\"overlay_navtop\").style.display = \"block\";
}

function w3_close() {
document.getElementById(\"sidetop\").style.display = \"none\";
document.getElementById(\"overlay_navtop\").style.display = \"none\";
}
</script>

<script src=\"assets/vendor/jquery/jquery.min.js\"></script>
<script src=\"assets/vendor/ladda/spin.min.js\"></script>
<script src=\"assets/vendor/ladda/ladda.min.js\"></script>
<script src=\"assets/vendor/toastr/build/toastr.min.js\"></script>
<script src=\"assets/jscontrollers/overall/toast.js\"></script>
<script src=\"assets/app/js/app.js\"></script>";
        // line 141
        $this->displayBlock('appFooter', $context, $blocks);
        // line 142
        echo "</body>
</html>
";
    }

    // line 15
    public function block_appHeader($context, array $blocks = array())
    {
    }

    // line 95
    public function block_appBody($context, array $blocks = array())
    {
    }

    // line 141
    public function block_appFooter($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "overall/layout.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  188 => 141,  183 => 95,  178 => 15,  172 => 142,  170 => 141,  124 => 96,  122 => 95,  120 => 92,  44 => 16,  42 => 15,  30 => 5,  26 => 4,  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "overall/layout.twig", "C:\\xampp\\htdocs\\m.gomuf\\app\\templates\\overall\\layout.twig");
    }
}
