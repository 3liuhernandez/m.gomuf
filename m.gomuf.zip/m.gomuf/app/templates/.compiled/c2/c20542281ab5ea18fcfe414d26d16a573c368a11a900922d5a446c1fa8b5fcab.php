<?php

/* home/home.twig */
class __TwigTemplate_2bda6a42a34dcdfb6dd190f97f4b6bc64304300b073add4f89e3c8d0a5165c3c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "home/home.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "<!-- Proyecto E-Book Section -->
<div class=\"w3-padding-64 w3-white\">
    <div class=\"w3-row-padding\">
        <div class=\"w3-col l8 m6\">
            <h2 class=\"w3-xlarge\"><b>Proyecto E-Book</b></h2>
            <strong class=\"w3-large w3-text-blue\"><b> REENCUENTRO CON LAS NUEVAS GENERACIONES POST COVID 19</b></strong>
            <p>
                <b class=\"w3-large\">Breve descripción del libro:</b><br>
                ¿Cómo conectar con las nuevas generaciones post COVID 19? ¿Cuáles serán los nuevos desafíos que nos traerá el nuevo escenario en trabajo con las nuevas generaciones? Este libro nos presenta una cosmovisión desde una perspectiva psicosocial y teológica de lo que podrían ser los posibles escenarios y modos de abordar en la conexión con los jóvenes luego de superada la pandemia. 
                <br><br>
                Un vistazo a las nuevas generaciones pre COVID 19, los efectos psicosociales en tiempo de cuarentena, el proceso de ampliar una mayor compresión de la nueva realidad para hacer ser efectivos y eficientes en el abordaje de los jóvenes para ayudarles a desarrollar su potencial integralmente. Anticipar los nuevos desafíos de este escenario post COVID 19, conectando con las nuevas generaciones de forma autentica para promover una metamorfosis total que afecte positivamente el futuro de nuestras naciones. 
                <br><br>
                Puedes descargar este libro que será útil para los jóvenes, líderes juveniles, docentes, profesores universitarios, padres y todas las organizaciones que trabajan en medio de las comunidades de las nuevas generaciones. Luego de leerlo déjanos saber tu opinión del libro, colgando tu comentario en esta página. 
                <br><br>
                GoMUF está trabajando en otros materiales y recursos útiles para todos! 
            </p>
            <p>
                <i><strong class=\"w3-xlarge\">Autor: Darío Ortega </strong></i> &nbsp;
                <a href=\"https://www.facebook.com/darluz.mufvalencia\" target=\"_blanck\"><i class=\"fa fa-facebook w3-xlarge w3-text-blue\"></i></a>
                <a href=\"https://www.instagram.com/darluz.ortega/\" target=\"_blanck\"><i class=\"fa fa-instagram w3-xlarge w3-text-purple\"></i></a>
                <a href=\"https://wa.link/g2z66d\" target=\"_blanck\"><i class=\"fa fa-whatsapp w3-xlarge w3-text-green\"></i></a>
            </p>
            
        </div>
        <div class=\"w3-col l4 m6\">
            <img src=\"assets/app/img/libro_mini.jpg\" class=\"w3-image w3-right w3-hide-small\" width=\"335\" height=\"471\">

            <button class=\"w3-button w3-light-grey w3-padding-large w3-section w3-hide-small w3-right\" onclick=\"document.getElementById('download').style.display='block'\">
                <i class=\"fa fa-download\"></i> Adquiere una copia del libro.
            </button>

            <div class=\"w3-center w3-hide-large w3-hide-medium\">
                <button class=\"w3-button w3-block w3-padding-large\" onclick=\"document.getElementById('download').style.display='block'\">
                    <i class=\"fa fa-download\"></i> Adquiere una copia del libro.
                </button>
                <img src=\"assets/app/img/libro_mini.jpeg\" class=\"w3-image w3-margin-top\" width=\"335\" height=\"471\">
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div id=\"download\" class=\"w3-modal w3-animate-opacity\">
    <div class=\"w3-modal-content\" style=\"padding:32px\">
        <div class=\"w3-row\">
            <form id=\"download_form\" class=\"w3-container w3-white w3-col l6 m7\">
                <h3 class=\"w3-wide w3-left w3-text-green\">
                    <i onclick=\"document.getElementById('download').style.display='none'\" class=\"fa fa-remove w3-xlarge w3-button w3-text-red w3-right w3-hover-text-green w3-hover-white\"></i>
                    <br>
                    <strong>REENCUENTRO CON LAS NUEVAS GENERACIONES POST COVID 19</strong>
                </h3>
                <p class=\"w3-large w3-text-gray\">
                    Antes de descargar una copia del libro, nos gustaría saber tu nombre, tu correo electrónico y también saber que expectativas tienes sobre el.
                    Esto con el fin de compatir a futuro comentarios sobre el E-book o crear un nuevo contacto con nuevos hermanos en Cristo.
                </p>
                <div class=\"w3-row-padding\" style=\"margin:0 -16px 8px -16px\">
                    <div class=\"w3-half\">
                        <input class=\"w3-input w3-border\" type=\"text\" placeholder=\"Nombre\" required name=\"name\">
                    </div>
                    <div class=\"w3-half\">
                        <input class=\"w3-input w3-border\" type=\"text\" placeholder=\"Correo Electrónico\" required name=\"email\">
                    </div>
                </div>
                <textarea col=\"5\" row=\"5\" class=\"w3-input w3-border\" placeholder=\"Mensaje\" required name=\"msj\"></textarea>
                <hr>
                <button id=\"download_btn\" type=\"submit\" class=\"w3-button w3-block w3-padding-large w3-red w3-margin-bottom\">Descargar E-Book</button>
            </form>
        </div>
    </div>
</div>

<!-- nosotros Proyecto MUF Section -->
<!-- div class=\"w3-padding-64 w3-light-grey bg-cover\" style=\"background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('assets/app/img/fondo.jpg');\" id=\"nosotros\">-->
<div class=\"w3-padding-64 w3-light-grey bg-cover\" style=\"background-image: url('assets/app/img/fondo.jpg'); background-position: bottom;\" id=\"nosotros\">

    <div class=\"w3-row-padding\">
        <div class=\"w3-col l12 m12 \">
            <p class=\"w3-center black-background title\">
                <b class=\"w3-xlarge\">Proyecto MUF </b>
                <br>
                <b class=\"w3-large w3-text-blue\"> Metamorfosis universitaria</b>
            </p>
        </div>
    </div>

    <div class=\"w3-row-padding w3-center\">
        <div class=\"w3-col l6 m6\">
            <p class=\"w3-xlarge black-background\">
                <span class=\"w3-xlarge w3-text-red title\">Misión </span><br>
                <span class=\"text w3-large\">
                    <b>Hacer discípulos multiplicadores a partir de la comunidad universitaria y profesional a través de un ministerio integral.</b>
                </span>
            </p>
        </div>
        <div class=\"w3-col l6 m6\">
            <p class=\"w3-xlarge black-background\">
                <span class=\"w3-xlarge w3-text-red title\">Visión</span><br>
                <span class=\"text w3-large\">
                    <b>Ver Valencia, Venezuela y el mundo liderada por personas comprometidas con Cristo.</b>
                </span>
            </p>
        </div>
    </div>
</div>

<!-- Valores Section -->
<div class=\"w3-container w3-padding-64 w3-center\" id=\"valores\">
    <p class=\"w3-xlarge\"><b>Valores</b></p>
    <p class=\"w3-large\">En nuestro entorno, cultivamos e insentivamos los valores.</p>

    <div class=\"w3-row\" style=\"margin-top:64px\">
        <div class=\"w3-col s6 m3\">
            <i class=\"fa fa-bolt w3-text-orange w3-xlarge\"></i>
            <p> <b>EXCELENCIA</b></p>
        </div>
        <div class=\"w3-col s6 m3\">
            <i class=\"fa fa-heart w3-text-red w3-xlarge\"></i>
            <p> <b>SOLIDARIDAD</b></p>
        </div>
        <div class=\"w3-col s6 m3\">
            <i class=\"fa fa-handshake-o w3-text-yellow w3-xlarge\"></i>
            <p> <b>COMPROMISO</b></p>
        </div>
        <div class=\"w3-col s6 m3\">
            <i class=\"fa fa-child w3-text-green w3-xlarge\"></i>
            <p> <b>GRATITUD </b></p>
        </div>
    </div>
</div>

<style>
    #staff .w3-row-padding .w3-col{
        float: left !important;
        position: relative;
    }
</style>
<!-- Staff Section -->
<div class=\"w3-container w3-light-gray\" style=\"padding:3%\" id=\"staff\">
    <h3 class=\"w3-center w3-xxlarge\">Staff</h3>

    <div class=\"w3-row-padding w3-grayscale\">
        <div class=\"w3-col l3 m6 s12 w3-margin-bottom\">
            <img src=\"assets/app/img/pastor0.png\" alt=\"Dario Ortega\" style=\"width:100%\" class=\"w3-image w3-round\">
            <h3>Darío Ortega</h3>
            <p class=\"w3-opacity\">CEO GOMUF</p>
            <p class=\"w3-large\">
                Terapeuta Psicosocial<br>
                Teólogo<br>
                Coaching de Liderazgo<br>
                Docente Universitario<br>
                Líder Chapel Navegantes del Magallanes (LBPV)<br>
                Coordinador FCA Carabobo<br>
                Miembro del equipo pastoral IB MUF Valencia
            </p>
        </div>

        <div class=\"w3-col l3 m6 s12 w3-margin-bottom\">
            <img src=\"assets/app/img/pastora.jpeg\" alt=\"Luzmery Albornoz de Ortega\" style=\"width:100%\" class=\"w3-image w3-round\">
            <h3>Luzmery de Ortega</h3>
            <p class=\"w3-opacity\">Directora GOMUF</p>
            <p class=\"w3-large\">
                Psicóloga<br>
                Terapeuta Psicosocial<br>
                Teólogo<br>
                Docente Universitaria<br>
                Líder Chapel Navegantes del Magallanes (LBPV)<br>
                Miembro del Equipo Pastoral IB MUF Valencia
            </p>
        </div>

        <div class=\"w3-row w3-hide-small w3-hide-large\"> <br><br></div>

        <div class=\"w3-col l3 m6 s12 w3-margin-bottom\">
            <img src=\"assets/app/img/santiago.jpg\" alt=\"Santiago Ortega\" style=\"width:100%\" class=\"w3-image w3-round\">
            <h3>Santiago Ortega</h3>
            <p class=\"w3-opacity\">Logística</p>
            <p class=\"w3-large\">
                Productor Musical
            </p>
        </div>

        <div class=\"w3-col l3 m6 s12 w3-margin-bottom\">
            <img src=\"assets/app/img/genesis1.jpeg\" alt=\"Génesis Ortega\" style=\"width:100%\" class=\"w3-image w3-round\">
            <h3>Génesis Ortega</h3>
            <p class=\"w3-opacity\">Community Manager</p>
            <p class=\"w3-large\">
                Escritora<br>
                Líder Universitario<br>
                Diseñador Grafico<br>
            </p>
        </div>
    </div>

</div>


<!-- campus accion Section -->
<div class=\"w3-container\" id=\"campus_accion\">
    <h3 class=\"w3-display-container w3-row w3-center w3-xlarge\">
        <b class=\"w3-text-white\">Campus de Acción</b><br>
        <i class=\"w3-text-blue\">Esfera Educación</i>
    </h3>
    
    <div class=\"w3-row w3-row-padding w3-center w3-text-red\">
        <div class=\"w3-col l2 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Universidad De Carabobo
            </div>
        </div>

        <div class=\"w3-col l2 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Universidad José Antonio Páez
            </div>
        </div>
    </div>

    <div class=\"w3-row w3-row-padding w3-center w3-text-red\">
        <div class=\"w3-col l2 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Universidad Arturo Michelena
            </div>
        </div>
        <div class=\"w3-col l2 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Universidad Alejandro De Humboldt
            </div>
        </div>
    </div>
    

    <div class=\"w3-row w3-row-padding w3-center w3-text-red\">
        <div class=\"w3-col l2 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Universidad Tecnológica Del Centro
            </div>
        </div>
        <div class=\"w3-col l3 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Instituto Universitario De Tecnología De Administración Industrial
            </div>
        </div>
    </div>

    <br><br>
    <div class=\"w3-row w3-row-padding w3-center w3-text-green\">

        <div class=\"w3-col l3 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container w3-padding nombre_casa_estudio\">
                Instituto Universitario De Nuevas Profesiones
            </div>
        </div>

        <div class=\"w3-col l3 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container w3-padding nombre_casa_estudio\">
                Instituto Universitario De Tecnología Antonio José De Sucre
            </div>
        </div>

        <div class=\"w3-col l3 m6 s12 w3-margin-bottom\">
            <div class=\"w3-display-container w3-padding nombre_casa_estudio\">
                Instituto Universitario De Tecnología Juan Pablo Pérez Alfonzo
            </div>
        </div>
    </div>

    <br><br>

    <div class=\"w3-row w3-row-padding w3-center w3-text-blue\">
        <div class=\"w3-col l2 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container w3-padding nombre_casa_estudio\">
                Colegio Universitario De Administración Y Mercadeo
            </div>
        </div>

        <div class=\"w3-col l2 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container w3-padding nombre_casa_estudio\">
                Colegio La Esperanza
            </div>
        </div>
    </div>

    <div class=\"w3-row w3-row-padding w3-center w3-text-blue\">
        <div class=\"w3-col l2 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container w3-padding nombre_casa_estudio\">
                Colegio Los Pinos
            </div>
        </div>

        <div class=\"w3-col l2 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container w3-padding nombre_casa_estudio\">
                Unidad Educativa Batalla De Bomboná
            </div>
        </div>
    </div>
    <div class=\"w3-row w3-row-padding w3-center w3-text-blue\">
        <div class=\"w3-col l2 m6 s12 w3-margin-bottom\">
            <div class=\"w3-display-container w3-padding nombre_casa_estudio\">
                Unidad Educativa Lago De Maracaibo
            </div>
        </div>
    </div>
    <br>
    <!-- Proyectos Con La Niñez -->
    <h3 class=\"w3-row w3-center w3-xlarge w3-display-container\">Proyectos con la Niñez</h3>
    <div class=\"w3-row w3-row-padding w3-center w3-text-blue\">
        <div class=\"w3-col s6 w3-margin-bottom\">
            <div class=\"w3-display-container w3-padding nombre_casa_estudio\">
                Programa Pepe Network
            </div>
        </div>

        <div class=\"w3-col s6 w3-margin-bottom\">
            <div class=\"w3-display-container w3-padding nombre_casa_estudio\">
                Proyecto Niños Bomboná 
            </div>
        </div>
    </div>
</div>


<!-- Staff Section -->
<div class=\"w3-container w3-white\" style=\"padding:128px 16px\" id=\"staff\">
    <div class=\"w3-row-padding w3-center margin-top\">
        <div class=\"w3-col l4 m4 s12 w3-margin-top\">
            <div class=\"w3-card\">
                <img src='assets/app/img/foto2.jpeg' alt=\"Luzmery Albornoz de Ortega\" style=\"width:100%\">
            </div>
        </div>

        <div class=\"w3-col l8 m8 w3-margin-top\">
            <p class=\"w3-large\">
                Ambos suman más de 25 años de experiencia de trabajo con los niños y los jóvenes en diferentes espacios, entre ellos los últimos años en los campus universitarios en Venezuela. Han participado en múltiples conferencias, congresos, talleres y charlas compartiendo experiencia y enseñanzas en medio de las nuevas generaciones.
            </p>
            <p class=\"w3-large\">
                Entrenamiento, charlas, talleres, asesoramiento, conferencias y acompañamiento integral a ministerios y organizaciones. (Liderazgo, Coaching, Psicología, Terapia Psicosocial) 
            </p>
        </div>
    </div>
</div>


<div class=\"w3-container\" id=\"alianzas\">
    <h3 class=\"w3-row w3-center w3-xlarge w3-display-container\">Alianzas<br><i class=\"\">Estratégicas</i></h3>

    <div class=\"w3-row w3-row-padding w3-text-white\">
        <div class=\"w3-col l6 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Charlottesville Community Church
            </div>
        </div>

        <div class=\"w3-col l6 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Casa Hogar Amor, Fe <br> Y Esperanza
            </div>
        </div>
    </div>
    <div class=\"w3-row w3-row-padding w3-text-white\">
        <div class=\"w3-col l6 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Grupo Rec / Alumbra
            </div>
        </div>
        <div class=\"w3-col l6 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Comité De Empresarios<br>Y Profesionales Cristianos
            </div>
        </div>
    </div>

    <div class=\"w3-row w3-row-padding w3-text-white\">
        <div class=\"w3-col l6 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Primera Iglesia Bautista<br>De Valencia
            </div>
        </div>

        <div class=\"w3-col l6 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Primera Iglesia Bautista<br>De Puerto Cabello
            </div>
        </div>
    </div>

    <div class=\"w3-row w3-row-padding w3-text-white\">
        <div class=\"w3-col l6 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Iglesia Real 
            </div>
        </div>

        <div class=\"w3-col l6 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Centro De Filosofía<br>Para La Investigación<br>tanislao Strba
            </div>
        </div>
    </div>

    <div class=\"w3-col l6 m6 s6 w3-margin-bottom\">
        <div class=\"w3-display-container nombre_casa_estudio\">
                Convención Nacional<br>Bautista De Venezuela
            </div>
        </div>
        <div class=\"w3-col l6 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Fellowship Of Christian Athletes
            </div>
        </div>
    </div>

</div>

<!-- Container (Contact Section) -->
<div class=\"w3-row w3-white\" id=\"contact\">
    <div class=\"w3-content w3-container w3-padding-64\" id=\"contact\">
        <h3 class=\"w3-center w3-xlarge\">Desde Aquí Trabajamos</h3>
        <p class=\"w3-center w3-large\"><em>Información de contacto</em></p>

        <div class=\"w3-row w3-padding-32 w3-section\">
            <div class=\"w3-col m4 w3-container\">
                <iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d26419.166210981297!2d-68.00438364898079!3d10.161742985473364!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e80678bce61928f%3A0x9f78e9eea8c34272!2sValencia%2C%20Carabobo!5e0!3m2!1ses-419!2sve!4v1588049595013!5m2!1ses-419!2sve\" width=\"100%\" height=\"450\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\" aria-hidden=\"false\" tabindex=\"0\"></iframe>
            </div>

            <div class=\"w3-col m8 w3-panel w3-text-gray\">
                <div class=\"w3-large w3-margin-bottom\">
                    <i class=\"fa fa-map-marker w3-text-blue\"></i>Valencia, Venezuela<br>
                    <i class=\"fa fa-phone w3-text-blue\"></i>+58 414 4371968<br>
                    <a href=\"mailto:gomuf.com@gmail.com\" target=\"_blanck\"> <i class=\"fa fa-envelope-o w3-text-blue\"></i>gomuf.com@gmail.com</a><br>
                    <a href=\"https://www.facebook.com/mufvalencia.ortegaalbornoz/\" target=\"_blanck\"><i class=\"fa fa-facebook w3-text-blue\"></i>Misión Última Frontera Valencia</a><br>
                    <a href=\"https://www.instagram.com/mufvalencia/\" target=\"_blanck\"><i class=\"fa fa-instagram w3-text-blue\"></i>@mufvalencia</a><br>
                </div>
                    <p class=\"w3-large\">Si gustas contactarte con nosotros, puedes enviarnos un mensaje a nuestro correo electronico o bien puedes escribirnos por aquí: </p>
                <form id=\"contact_form\">
                    <div class=\"w3-row-padding\" style=\"margin:0 -16px 8px -16px\">
                        <div class=\"w3-half\">
                            <input class=\"w3-input w3-border\" type=\"text\" placeholder=\"Nombre\" required name=\"name\">
                        </div>
                        <div class=\"w3-half\">
                            <input class=\"w3-input w3-border\" type=\"text\" placeholder=\"Correo Electrónico\" required name=\"email\">
                        </div>
                    </div>
                    <input class=\"w3-input w3-border\" type=\"text\" placeholder=\"Mensaje\" required name=\"msj\">
                    <button id=\"contact_btn\" class=\"w3-button w3-green w3-hover-text-green w3-right w3-section\" type=\"submit\">
                        <i class=\"fa fa-paper-plane\"></i> Envíar Mensaje
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>";
    }

    // line 457
    public function block_appFooter($context, array $blocks = array())
    {
        // line 458
        echo "<script src=\"assets/jscontrollers/home/actions.js\"></script>";
    }

    public function getTemplateName()
    {
        return "home/home.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  489 => 458,  486 => 457,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'overall/layout' %}
{% block appBody %}
<!-- Proyecto E-Book Section -->
<div class=\"w3-padding-64 w3-white\">
    <div class=\"w3-row-padding\">
        <div class=\"w3-col l8 m6\">
            <h2 class=\"w3-xlarge\"><b>Proyecto E-Book</b></h2>
            <strong class=\"w3-large w3-text-blue\"><b> REENCUENTRO CON LAS NUEVAS GENERACIONES POST COVID 19</b></strong>
            <p>
                <b class=\"w3-large\">Breve descripción del libro:</b><br>
                ¿Cómo conectar con las nuevas generaciones post COVID 19? ¿Cuáles serán los nuevos desafíos que nos traerá el nuevo escenario en trabajo con las nuevas generaciones? Este libro nos presenta una cosmovisión desde una perspectiva psicosocial y teológica de lo que podrían ser los posibles escenarios y modos de abordar en la conexión con los jóvenes luego de superada la pandemia. 
                <br><br>
                Un vistazo a las nuevas generaciones pre COVID 19, los efectos psicosociales en tiempo de cuarentena, el proceso de ampliar una mayor compresión de la nueva realidad para hacer ser efectivos y eficientes en el abordaje de los jóvenes para ayudarles a desarrollar su potencial integralmente. Anticipar los nuevos desafíos de este escenario post COVID 19, conectando con las nuevas generaciones de forma autentica para promover una metamorfosis total que afecte positivamente el futuro de nuestras naciones. 
                <br><br>
                Puedes descargar este libro que será útil para los jóvenes, líderes juveniles, docentes, profesores universitarios, padres y todas las organizaciones que trabajan en medio de las comunidades de las nuevas generaciones. Luego de leerlo déjanos saber tu opinión del libro, colgando tu comentario en esta página. 
                <br><br>
                GoMUF está trabajando en otros materiales y recursos útiles para todos! 
            </p>
            <p>
                <i><strong class=\"w3-xlarge\">Autor: Darío Ortega </strong></i> &nbsp;
                <a href=\"https://www.facebook.com/darluz.mufvalencia\" target=\"_blanck\"><i class=\"fa fa-facebook w3-xlarge w3-text-blue\"></i></a>
                <a href=\"https://www.instagram.com/darluz.ortega/\" target=\"_blanck\"><i class=\"fa fa-instagram w3-xlarge w3-text-purple\"></i></a>
                <a href=\"https://wa.link/g2z66d\" target=\"_blanck\"><i class=\"fa fa-whatsapp w3-xlarge w3-text-green\"></i></a>
            </p>
            
        </div>
        <div class=\"w3-col l4 m6\">
            <img src=\"assets/app/img/libro_mini.jpg\" class=\"w3-image w3-right w3-hide-small\" width=\"335\" height=\"471\">

            <button class=\"w3-button w3-light-grey w3-padding-large w3-section w3-hide-small w3-right\" onclick=\"document.getElementById('download').style.display='block'\">
                <i class=\"fa fa-download\"></i> Adquiere una copia del libro.
            </button>

            <div class=\"w3-center w3-hide-large w3-hide-medium\">
                <button class=\"w3-button w3-block w3-padding-large\" onclick=\"document.getElementById('download').style.display='block'\">
                    <i class=\"fa fa-download\"></i> Adquiere una copia del libro.
                </button>
                <img src=\"assets/app/img/libro_mini.jpeg\" class=\"w3-image w3-margin-top\" width=\"335\" height=\"471\">
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div id=\"download\" class=\"w3-modal w3-animate-opacity\">
    <div class=\"w3-modal-content\" style=\"padding:32px\">
        <div class=\"w3-row\">
            <form id=\"download_form\" class=\"w3-container w3-white w3-col l6 m7\">
                <h3 class=\"w3-wide w3-left w3-text-green\">
                    <i onclick=\"document.getElementById('download').style.display='none'\" class=\"fa fa-remove w3-xlarge w3-button w3-text-red w3-right w3-hover-text-green w3-hover-white\"></i>
                    <br>
                    <strong>REENCUENTRO CON LAS NUEVAS GENERACIONES POST COVID 19</strong>
                </h3>
                <p class=\"w3-large w3-text-gray\">
                    Antes de descargar una copia del libro, nos gustaría saber tu nombre, tu correo electrónico y también saber que expectativas tienes sobre el.
                    Esto con el fin de compatir a futuro comentarios sobre el E-book o crear un nuevo contacto con nuevos hermanos en Cristo.
                </p>
                <div class=\"w3-row-padding\" style=\"margin:0 -16px 8px -16px\">
                    <div class=\"w3-half\">
                        <input class=\"w3-input w3-border\" type=\"text\" placeholder=\"Nombre\" required name=\"name\">
                    </div>
                    <div class=\"w3-half\">
                        <input class=\"w3-input w3-border\" type=\"text\" placeholder=\"Correo Electrónico\" required name=\"email\">
                    </div>
                </div>
                <textarea col=\"5\" row=\"5\" class=\"w3-input w3-border\" placeholder=\"Mensaje\" required name=\"msj\"></textarea>
                <hr>
                <button id=\"download_btn\" type=\"submit\" class=\"w3-button w3-block w3-padding-large w3-red w3-margin-bottom\">Descargar E-Book</button>
            </form>
        </div>
    </div>
</div>

<!-- nosotros Proyecto MUF Section -->
<!-- div class=\"w3-padding-64 w3-light-grey bg-cover\" style=\"background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('assets/app/img/fondo.jpg');\" id=\"nosotros\">-->
<div class=\"w3-padding-64 w3-light-grey bg-cover\" style=\"background-image: url('assets/app/img/fondo.jpg'); background-position: bottom;\" id=\"nosotros\">

    <div class=\"w3-row-padding\">
        <div class=\"w3-col l12 m12 \">
            <p class=\"w3-center black-background title\">
                <b class=\"w3-xlarge\">Proyecto MUF </b>
                <br>
                <b class=\"w3-large w3-text-blue\"> Metamorfosis universitaria</b>
            </p>
        </div>
    </div>

    <div class=\"w3-row-padding w3-center\">
        <div class=\"w3-col l6 m6\">
            <p class=\"w3-xlarge black-background\">
                <span class=\"w3-xlarge w3-text-red title\">Misión </span><br>
                <span class=\"text w3-large\">
                    <b>Hacer discípulos multiplicadores a partir de la comunidad universitaria y profesional a través de un ministerio integral.</b>
                </span>
            </p>
        </div>
        <div class=\"w3-col l6 m6\">
            <p class=\"w3-xlarge black-background\">
                <span class=\"w3-xlarge w3-text-red title\">Visión</span><br>
                <span class=\"text w3-large\">
                    <b>Ver Valencia, Venezuela y el mundo liderada por personas comprometidas con Cristo.</b>
                </span>
            </p>
        </div>
    </div>
</div>

<!-- Valores Section -->
<div class=\"w3-container w3-padding-64 w3-center\" id=\"valores\">
    <p class=\"w3-xlarge\"><b>Valores</b></p>
    <p class=\"w3-large\">En nuestro entorno, cultivamos e insentivamos los valores.</p>

    <div class=\"w3-row\" style=\"margin-top:64px\">
        <div class=\"w3-col s6 m3\">
            <i class=\"fa fa-bolt w3-text-orange w3-xlarge\"></i>
            <p> <b>EXCELENCIA</b></p>
        </div>
        <div class=\"w3-col s6 m3\">
            <i class=\"fa fa-heart w3-text-red w3-xlarge\"></i>
            <p> <b>SOLIDARIDAD</b></p>
        </div>
        <div class=\"w3-col s6 m3\">
            <i class=\"fa fa-handshake-o w3-text-yellow w3-xlarge\"></i>
            <p> <b>COMPROMISO</b></p>
        </div>
        <div class=\"w3-col s6 m3\">
            <i class=\"fa fa-child w3-text-green w3-xlarge\"></i>
            <p> <b>GRATITUD </b></p>
        </div>
    </div>
</div>

<style>
    #staff .w3-row-padding .w3-col{
        float: left !important;
        position: relative;
    }
</style>
<!-- Staff Section -->
<div class=\"w3-container w3-light-gray\" style=\"padding:3%\" id=\"staff\">
    <h3 class=\"w3-center w3-xxlarge\">Staff</h3>

    <div class=\"w3-row-padding w3-grayscale\">
        <div class=\"w3-col l3 m6 s12 w3-margin-bottom\">
            <img src=\"assets/app/img/pastor0.png\" alt=\"Dario Ortega\" style=\"width:100%\" class=\"w3-image w3-round\">
            <h3>Darío Ortega</h3>
            <p class=\"w3-opacity\">CEO GOMUF</p>
            <p class=\"w3-large\">
                Terapeuta Psicosocial<br>
                Teólogo<br>
                Coaching de Liderazgo<br>
                Docente Universitario<br>
                Líder Chapel Navegantes del Magallanes (LBPV)<br>
                Coordinador FCA Carabobo<br>
                Miembro del equipo pastoral IB MUF Valencia
            </p>
        </div>

        <div class=\"w3-col l3 m6 s12 w3-margin-bottom\">
            <img src=\"assets/app/img/pastora.jpeg\" alt=\"Luzmery Albornoz de Ortega\" style=\"width:100%\" class=\"w3-image w3-round\">
            <h3>Luzmery de Ortega</h3>
            <p class=\"w3-opacity\">Directora GOMUF</p>
            <p class=\"w3-large\">
                Psicóloga<br>
                Terapeuta Psicosocial<br>
                Teólogo<br>
                Docente Universitaria<br>
                Líder Chapel Navegantes del Magallanes (LBPV)<br>
                Miembro del Equipo Pastoral IB MUF Valencia
            </p>
        </div>

        <div class=\"w3-row w3-hide-small w3-hide-large\"> <br><br></div>

        <div class=\"w3-col l3 m6 s12 w3-margin-bottom\">
            <img src=\"assets/app/img/santiago.jpg\" alt=\"Santiago Ortega\" style=\"width:100%\" class=\"w3-image w3-round\">
            <h3>Santiago Ortega</h3>
            <p class=\"w3-opacity\">Logística</p>
            <p class=\"w3-large\">
                Productor Musical
            </p>
        </div>

        <div class=\"w3-col l3 m6 s12 w3-margin-bottom\">
            <img src=\"assets/app/img/genesis1.jpeg\" alt=\"Génesis Ortega\" style=\"width:100%\" class=\"w3-image w3-round\">
            <h3>Génesis Ortega</h3>
            <p class=\"w3-opacity\">Community Manager</p>
            <p class=\"w3-large\">
                Escritora<br>
                Líder Universitario<br>
                Diseñador Grafico<br>
            </p>
        </div>
    </div>

</div>


<!-- campus accion Section -->
<div class=\"w3-container\" id=\"campus_accion\">
    <h3 class=\"w3-display-container w3-row w3-center w3-xlarge\">
        <b class=\"w3-text-white\">Campus de Acción</b><br>
        <i class=\"w3-text-blue\">Esfera Educación</i>
    </h3>
    
    <div class=\"w3-row w3-row-padding w3-center w3-text-red\">
        <div class=\"w3-col l2 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Universidad De Carabobo
            </div>
        </div>

        <div class=\"w3-col l2 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Universidad José Antonio Páez
            </div>
        </div>
    </div>

    <div class=\"w3-row w3-row-padding w3-center w3-text-red\">
        <div class=\"w3-col l2 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Universidad Arturo Michelena
            </div>
        </div>
        <div class=\"w3-col l2 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Universidad Alejandro De Humboldt
            </div>
        </div>
    </div>
    

    <div class=\"w3-row w3-row-padding w3-center w3-text-red\">
        <div class=\"w3-col l2 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Universidad Tecnológica Del Centro
            </div>
        </div>
        <div class=\"w3-col l3 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Instituto Universitario De Tecnología De Administración Industrial
            </div>
        </div>
    </div>

    <br><br>
    <div class=\"w3-row w3-row-padding w3-center w3-text-green\">

        <div class=\"w3-col l3 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container w3-padding nombre_casa_estudio\">
                Instituto Universitario De Nuevas Profesiones
            </div>
        </div>

        <div class=\"w3-col l3 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container w3-padding nombre_casa_estudio\">
                Instituto Universitario De Tecnología Antonio José De Sucre
            </div>
        </div>

        <div class=\"w3-col l3 m6 s12 w3-margin-bottom\">
            <div class=\"w3-display-container w3-padding nombre_casa_estudio\">
                Instituto Universitario De Tecnología Juan Pablo Pérez Alfonzo
            </div>
        </div>
    </div>

    <br><br>

    <div class=\"w3-row w3-row-padding w3-center w3-text-blue\">
        <div class=\"w3-col l2 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container w3-padding nombre_casa_estudio\">
                Colegio Universitario De Administración Y Mercadeo
            </div>
        </div>

        <div class=\"w3-col l2 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container w3-padding nombre_casa_estudio\">
                Colegio La Esperanza
            </div>
        </div>
    </div>

    <div class=\"w3-row w3-row-padding w3-center w3-text-blue\">
        <div class=\"w3-col l2 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container w3-padding nombre_casa_estudio\">
                Colegio Los Pinos
            </div>
        </div>

        <div class=\"w3-col l2 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container w3-padding nombre_casa_estudio\">
                Unidad Educativa Batalla De Bomboná
            </div>
        </div>
    </div>
    <div class=\"w3-row w3-row-padding w3-center w3-text-blue\">
        <div class=\"w3-col l2 m6 s12 w3-margin-bottom\">
            <div class=\"w3-display-container w3-padding nombre_casa_estudio\">
                Unidad Educativa Lago De Maracaibo
            </div>
        </div>
    </div>
    <br>
    <!-- Proyectos Con La Niñez -->
    <h3 class=\"w3-row w3-center w3-xlarge w3-display-container\">Proyectos con la Niñez</h3>
    <div class=\"w3-row w3-row-padding w3-center w3-text-blue\">
        <div class=\"w3-col s6 w3-margin-bottom\">
            <div class=\"w3-display-container w3-padding nombre_casa_estudio\">
                Programa Pepe Network
            </div>
        </div>

        <div class=\"w3-col s6 w3-margin-bottom\">
            <div class=\"w3-display-container w3-padding nombre_casa_estudio\">
                Proyecto Niños Bomboná 
            </div>
        </div>
    </div>
</div>


<!-- Staff Section -->
<div class=\"w3-container w3-white\" style=\"padding:128px 16px\" id=\"staff\">
    <div class=\"w3-row-padding w3-center margin-top\">
        <div class=\"w3-col l4 m4 s12 w3-margin-top\">
            <div class=\"w3-card\">
                <img src='assets/app/img/foto2.jpeg' alt=\"Luzmery Albornoz de Ortega\" style=\"width:100%\">
            </div>
        </div>

        <div class=\"w3-col l8 m8 w3-margin-top\">
            <p class=\"w3-large\">
                Ambos suman más de 25 años de experiencia de trabajo con los niños y los jóvenes en diferentes espacios, entre ellos los últimos años en los campus universitarios en Venezuela. Han participado en múltiples conferencias, congresos, talleres y charlas compartiendo experiencia y enseñanzas en medio de las nuevas generaciones.
            </p>
            <p class=\"w3-large\">
                Entrenamiento, charlas, talleres, asesoramiento, conferencias y acompañamiento integral a ministerios y organizaciones. (Liderazgo, Coaching, Psicología, Terapia Psicosocial) 
            </p>
        </div>
    </div>
</div>


<div class=\"w3-container\" id=\"alianzas\">
    <h3 class=\"w3-row w3-center w3-xlarge w3-display-container\">Alianzas<br><i class=\"\">Estratégicas</i></h3>

    <div class=\"w3-row w3-row-padding w3-text-white\">
        <div class=\"w3-col l6 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Charlottesville Community Church
            </div>
        </div>

        <div class=\"w3-col l6 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Casa Hogar Amor, Fe <br> Y Esperanza
            </div>
        </div>
    </div>
    <div class=\"w3-row w3-row-padding w3-text-white\">
        <div class=\"w3-col l6 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Grupo Rec / Alumbra
            </div>
        </div>
        <div class=\"w3-col l6 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Comité De Empresarios<br>Y Profesionales Cristianos
            </div>
        </div>
    </div>

    <div class=\"w3-row w3-row-padding w3-text-white\">
        <div class=\"w3-col l6 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Primera Iglesia Bautista<br>De Valencia
            </div>
        </div>

        <div class=\"w3-col l6 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Primera Iglesia Bautista<br>De Puerto Cabello
            </div>
        </div>
    </div>

    <div class=\"w3-row w3-row-padding w3-text-white\">
        <div class=\"w3-col l6 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Iglesia Real 
            </div>
        </div>

        <div class=\"w3-col l6 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Centro De Filosofía<br>Para La Investigación<br>tanislao Strba
            </div>
        </div>
    </div>

    <div class=\"w3-col l6 m6 s6 w3-margin-bottom\">
        <div class=\"w3-display-container nombre_casa_estudio\">
                Convención Nacional<br>Bautista De Venezuela
            </div>
        </div>
        <div class=\"w3-col l6 m6 s6 w3-margin-bottom\">
            <div class=\"w3-display-container nombre_casa_estudio\">
                Fellowship Of Christian Athletes
            </div>
        </div>
    </div>

</div>

<!-- Container (Contact Section) -->
<div class=\"w3-row w3-white\" id=\"contact\">
    <div class=\"w3-content w3-container w3-padding-64\" id=\"contact\">
        <h3 class=\"w3-center w3-xlarge\">Desde Aquí Trabajamos</h3>
        <p class=\"w3-center w3-large\"><em>Información de contacto</em></p>

        <div class=\"w3-row w3-padding-32 w3-section\">
            <div class=\"w3-col m4 w3-container\">
                <iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d26419.166210981297!2d-68.00438364898079!3d10.161742985473364!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e80678bce61928f%3A0x9f78e9eea8c34272!2sValencia%2C%20Carabobo!5e0!3m2!1ses-419!2sve!4v1588049595013!5m2!1ses-419!2sve\" width=\"100%\" height=\"450\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\" aria-hidden=\"false\" tabindex=\"0\"></iframe>
            </div>

            <div class=\"w3-col m8 w3-panel w3-text-gray\">
                <div class=\"w3-large w3-margin-bottom\">
                    <i class=\"fa fa-map-marker w3-text-blue\"></i>Valencia, Venezuela<br>
                    <i class=\"fa fa-phone w3-text-blue\"></i>+58 414 4371968<br>
                    <a href=\"mailto:gomuf.com@gmail.com\" target=\"_blanck\"> <i class=\"fa fa-envelope-o w3-text-blue\"></i>gomuf.com@gmail.com</a><br>
                    <a href=\"https://www.facebook.com/mufvalencia.ortegaalbornoz/\" target=\"_blanck\"><i class=\"fa fa-facebook w3-text-blue\"></i>Misión Última Frontera Valencia</a><br>
                    <a href=\"https://www.instagram.com/mufvalencia/\" target=\"_blanck\"><i class=\"fa fa-instagram w3-text-blue\"></i>@mufvalencia</a><br>
                </div>
                    <p class=\"w3-large\">Si gustas contactarte con nosotros, puedes enviarnos un mensaje a nuestro correo electronico o bien puedes escribirnos por aquí: </p>
                <form id=\"contact_form\">
                    <div class=\"w3-row-padding\" style=\"margin:0 -16px 8px -16px\">
                        <div class=\"w3-half\">
                            <input class=\"w3-input w3-border\" type=\"text\" placeholder=\"Nombre\" required name=\"name\">
                        </div>
                        <div class=\"w3-half\">
                            <input class=\"w3-input w3-border\" type=\"text\" placeholder=\"Correo Electrónico\" required name=\"email\">
                        </div>
                    </div>
                    <input class=\"w3-input w3-border\" type=\"text\" placeholder=\"Mensaje\" required name=\"msj\">
                    <button id=\"contact_btn\" class=\"w3-button w3-green w3-hover-text-green w3-right w3-section\" type=\"submit\">
                        <i class=\"fa fa-paper-plane\"></i> Envíar Mensaje
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

{% endblock %}

{% block appFooter %}
<script src=\"assets/jscontrollers/home/actions.js\"></script>
{% endblock %}", "home/home.twig", "C:\\xampp\\htdocs\\m.gomuf\\app\\templates\\home\\home.twig");
    }
}
